package br.com.globalcode.bean;

import br.com.globalcode.service.NewsService;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.inject.Named;

/**
 *
 * 1 - Defina o bean com escopo de sessao
 * 2 - Deixe que o mecanismo de injeção de dependência injete a implementação no atributo 
 * 'newsService', modificando a injeção pela anotação @EJB
 */
@Named
public class NewsBean implements Serializable{
    private String mail;
    
    @EJB
    private NewsService newsService;
    
    public void salvar(){
        newsService.salvar(mail);
        mail = null;
    }
    
    public List<String> getAssinantes(){
        return newsService.buscarAssinantes();
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }
    
    
}
