package br.com.globalcode.dao;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Stateless;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
@Stateless
public class NewsDAOImpl implements NewsDAO, Serializable{
    
    private static List<String> mails;

    @Override
    public void salvar(String mail) {
        mails.add(mail);
    }

    @Override
    public List<String> getMails() {
        if(mails == null)
            mails = new ArrayList<String>();
        
        return mails;
    }
    
}
