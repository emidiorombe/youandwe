package br.com.globalcode.service;

import br.com.globalcode.dao.NewsDAO;
import java.io.Serializable;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.Stateless;

/**
 * 1 - Insira a anotação Named para que o bean passe a ser gerenciado pelo mecanismo de CDI
 * 2 - Deixe que o mecanismo de injeção de dependência injete a 
 * implementação no atributo 'newsDAO', modificando a injeção pela anotação @EJB
 */
@Stateless
public class NewsService implements Serializable {
    @EJB
    private NewsDAO newsDAO;
    
    public void salvar(String mail){
        newsDAO.salvar(mail);
    }
    
    public List<String> buscarAssinantes(){
        return newsDAO.getMails();
    }
}
