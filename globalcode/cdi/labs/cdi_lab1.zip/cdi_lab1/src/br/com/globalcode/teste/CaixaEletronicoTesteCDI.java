package br.com.globalcode.teste;

import br.com.globalcode.caixa.CaixaEletronico;
import java.math.BigDecimal;
import org.cdisource.beancontainer.BeanContainer;
import org.cdisource.beancontainer.BeanContainerManager;

/**
 *
 * 1 - Inicialize a variavel 'cx', buscando no beanContainer pelo bean de nome 'caixaCDI'
 */
public class CaixaEletronicoTesteCDI {
    static BeanContainer beanContainer =  BeanContainerManager.getInstance();

    public static void main(String args[]){
        CaixaEletronico cx = null;
        cx.depositar(new BigDecimal(2500.0));
        cx.sacar(new BigDecimal(500.0));
    }
}
