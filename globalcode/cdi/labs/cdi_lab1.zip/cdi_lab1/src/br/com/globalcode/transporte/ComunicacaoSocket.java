package br.com.globalcode.transporte;


/**
 *
 * 1 - Marque a classe com implementação padrão(Default) do mecanismo de injeção de dependência
 */
public class ComunicacaoSocket implements Comunicacao{

    @Override
    public void comunicarComBanco(String dados) {
        System.out.println("Comunicando com o banco via Socket na porta 1234");
    }
    
}
