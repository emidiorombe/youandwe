package br.com.globalcode.caixa;

import br.com.globalcode.transporte.Comunicacao;
import java.math.BigDecimal;
import javax.inject.Named;

/**
 *
 * 1 - Insira a classe no contexto de injeção de dependência dando o nome 'caixaCDI' como sua referência
 * 2 - Inicialize o atributo 'transporte', através do mecanismo de injeção de dependência no método setTrasporte
 *  
 */

public class CaixaEletronicoComCDI implements CaixaEletronico{
    private Comunicacao transporte;
    
    @Override
    public void setTransporte(Comunicacao transporte){
        this.transporte = transporte;
    }
    

    @Override
    public void depositar(BigDecimal bd) {
        transporte.comunicarComBanco(bd.toString());
        System.out.println("Realizando deposito de R$" + bd.doubleValue());
    }

    @Override
    public void sacar(BigDecimal bd) {
        transporte.comunicarComBanco(bd.toString());
        System.out.println("Realizando saque de R$" + bd.doubleValue());
    }
    
}
