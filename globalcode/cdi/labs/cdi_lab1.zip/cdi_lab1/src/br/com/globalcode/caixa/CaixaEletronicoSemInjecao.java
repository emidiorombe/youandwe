package br.com.globalcode.caixa;

import br.com.globalcode.transporte.Comunicacao;
import java.math.BigDecimal;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
public class CaixaEletronicoSemInjecao implements CaixaEletronico{
    
    private Comunicacao transporte;
    
    public CaixaEletronicoSemInjecao(){}
    
    //Pode se inicializar a forma de transporte através do construtor da classe.
    public CaixaEletronicoSemInjecao(Comunicacao transporte){
        this.transporte = transporte;
    }
    
    //Outra alternativa de inicializacao da forma de transporte,
    //é através de um método setter
    @Override
    public void setTransporte(Comunicacao transporte){
        this.transporte = transporte;
    }
    

    @Override
    public void depositar(BigDecimal bd) {
        System.out.println("Realizando deposito de R$" + bd.doubleValue());
        transporte.comunicarComBanco(bd.toString());
        
    }

    @Override
    public void sacar(BigDecimal bd) {
        System.out.println("Realizando saque de R$" + bd.doubleValue());
        transporte.comunicarComBanco(bd.toString());
    }
    
}
