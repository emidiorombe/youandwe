package br.com.globalcode.transporte;


/**
 *
 * 1 - Marque a classe como implementação alternativa(Alterntive) para o mecanismo de injeção de dependência
 */
public class ComunicacaoEJB implements Comunicacao{

    @Override
    public void comunicarComBanco(String dados) {
        System.out.println("Comunicando com o banco via EJB");
    }
    
}
