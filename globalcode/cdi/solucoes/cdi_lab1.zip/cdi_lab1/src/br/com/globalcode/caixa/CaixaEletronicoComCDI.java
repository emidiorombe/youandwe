package br.com.globalcode.caixa;

import br.com.globalcode.transporte.Comunicacao;
import java.math.BigDecimal;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
@Named("caixaCDI")
public class CaixaEletronicoComCDI implements CaixaEletronico{
    private Comunicacao transporte;
    
    @Override
    @Inject
    public void setTransporte(Comunicacao transporte){
        this.transporte = transporte;
    }
    

    @Override
    public void depositar(BigDecimal bd) {
        transporte.comunicarComBanco(bd.toString());
        System.out.println("Realizando deposito de R$" + bd.doubleValue());
    }

    @Override
    public void sacar(BigDecimal bd) {
        transporte.comunicarComBanco(bd.toString());
        System.out.println("Realizando saque de R$" + bd.doubleValue());
    }
    
}
