package br.com.globalcode.teste;

import br.com.globalcode.caixa.CaixaEletronico;
import br.com.globalcode.caixa.CaixaEletronicoSemInjecao;
import br.com.globalcode.transporte.Comunicacao;
import br.com.globalcode.transporte.ComunicacaoSocket;
import java.math.BigDecimal;

/**
 * Classe de teste de Caixa Eletronico sem Injeção de Dependência
 * @author Rafael Nunes
 */
public class CaixaEletronicoTest {
    public static void main(String args[]){
        CaixaEletronico cx = new CaixaEletronicoSemInjecao();
        Comunicacao transporte = new ComunicacaoSocket();
        
        cx.setTransporte(transporte);
        
        cx.sacar(new BigDecimal(500.0));
        cx.depositar(new BigDecimal(2000.0));
        
    }
            
}
