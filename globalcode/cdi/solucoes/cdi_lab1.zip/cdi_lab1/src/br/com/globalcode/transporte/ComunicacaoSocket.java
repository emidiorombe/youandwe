package br.com.globalcode.transporte;

import javax.enterprise.inject.Default;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
@Default
public class ComunicacaoSocket implements Comunicacao{

    @Override
    public void comunicarComBanco(String dados) {
        System.out.println("Comunicando com o banco via Socket na porta 1234");
    }
    
}
