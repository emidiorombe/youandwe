package br.com.globalcode.transporte;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
public interface Comunicacao {
    void comunicarComBanco(String dados);
}
