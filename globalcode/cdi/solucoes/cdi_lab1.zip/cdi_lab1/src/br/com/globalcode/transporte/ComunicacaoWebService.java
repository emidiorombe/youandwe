package br.com.globalcode.transporte;

import javax.enterprise.inject.Alternative;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
@Alternative
public class ComunicacaoWebService implements Comunicacao{

    @Override
    public void comunicarComBanco(String dados) {
        System.out.println("Comunicando com o banco via WebService SOAP");
    }
    
}
