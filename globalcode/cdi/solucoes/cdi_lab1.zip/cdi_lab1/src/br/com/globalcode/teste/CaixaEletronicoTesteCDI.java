package br.com.globalcode.teste;

import br.com.globalcode.caixa.CaixaEletronico;
import java.math.BigDecimal;
import org.cdisource.beancontainer.BeanContainer;
import org.cdisource.beancontainer.BeanContainerManager;

/**
 *
 * @author Rafael Nunes <rafael@yaw.com.br>
 */
public class CaixaEletronicoTesteCDI {
    static BeanContainer beanContainer =  BeanContainerManager.getInstance();

    public static void main(String args[]){
        CaixaEletronico cx = (CaixaEletronico) beanContainer.getBeanByName("caixaCDI");
        cx.depositar(new BigDecimal(2500.0));
        cx.sacar(new BigDecimal(500.0));
    }
}
