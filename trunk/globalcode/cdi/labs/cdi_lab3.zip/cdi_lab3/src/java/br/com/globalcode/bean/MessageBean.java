package br.com.globalcode.bean;

import java.io.Serializable;
import java.util.Random;

/**
 *
 * 1 - Defina a classe como um bean gerenciado pelo mecanismo de injeção de dependência
 */
public class MessageBean implements Serializable{
    
    public String getMessage(){
        return "ManagedBean injetado via CDI ";
    }
    
    public void click(){
        System.out.println("Executando método do ManagedBean");
    }

    public Integer getNumber() {
        return new Random().nextInt();
    }

    
    
}
