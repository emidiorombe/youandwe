package br.com.globalcode.transporte;

/**
 *
 * 1 - Defina a classe com o qualificador WebService para o mecanismo de injeção de dependência
 */
public class ComunicacaoWebService implements Comunicacao{

    @Override
    public void comunicarComBanco(String dados) {
        System.out.println("Comunicando com o banco via WebService SOAP");
    }
    
}
