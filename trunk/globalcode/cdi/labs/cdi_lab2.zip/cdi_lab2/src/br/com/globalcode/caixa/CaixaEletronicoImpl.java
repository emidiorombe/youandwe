package br.com.globalcode.caixa;

import br.com.globalcode.transporte.Comunicacao;
import java.math.BigDecimal;
import javax.inject.Inject;
import javax.inject.Named;


/**
 *
 * 1 - Defina dos qualificadores criados, qual sera injetado no atributo 'transporte'
 */
@Named("caixaQ")
public class CaixaEletronicoImpl implements CaixaEletronico{
    
    @Inject
    private Comunicacao transporte;
    
    
    @Override
    public void depositar(BigDecimal bd) {
        transporte.comunicarComBanco(bd.toString());
        System.out.println("Realizando deposito de R$" + bd.doubleValue());
    }

    @Override
    public void sacar(BigDecimal bd) {
        transporte.comunicarComBanco(bd.toString());
        System.out.println("Realizando saque de R$" + bd.doubleValue());
    }
    
}
