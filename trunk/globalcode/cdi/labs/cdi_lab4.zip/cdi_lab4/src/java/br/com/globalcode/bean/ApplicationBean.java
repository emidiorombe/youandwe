package br.com.globalcode.bean;

import java.io.Serializable;
import javax.inject.Named;

/**
 *
 * 1 - Defina o bean com escopo de aplicação
 */
@Named
public class ApplicationBean implements Serializable{
    private Integer contador = 0;
    
    public void incrementar(){
        ++contador;
    }
    
    public Integer getContador(){
        return contador;
    }
}
