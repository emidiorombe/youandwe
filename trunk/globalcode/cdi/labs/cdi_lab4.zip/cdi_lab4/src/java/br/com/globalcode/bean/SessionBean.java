package br.com.globalcode.bean;

import java.io.Serializable;
import javax.inject.Named;

/**
 *
 * 1 - Defina o bean com escopo de sessao
 */
@Named
public class SessionBean implements Serializable {
    private Integer contador = 0;
    
    public void incrementar(){
        ++contador;
    }
    
    public Integer getContador(){
        return contador;
    }
}
