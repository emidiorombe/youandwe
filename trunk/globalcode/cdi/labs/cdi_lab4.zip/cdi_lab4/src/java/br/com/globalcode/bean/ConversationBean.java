package br.com.globalcode.bean;

import java.io.Serializable;
import javax.enterprise.context.Conversation;
import javax.enterprise.context.ConversationScoped;
import javax.inject.Inject;
import javax.inject.Named;

/**
 *
 * 1 - Defina o bean com escopo de conversacao
 * 2 - Crie um atributo do tipo Conversation, e injete pelo mencanismo de injecao de dependencia a implementação
 * 3 - No método 'finalizar', caso a conversacao não seja transiente, finalize a conversacao através do método 'end'
 */
@Named
public class ConversationBean implements Serializable{
    private Integer contador = 0;
    
    @Inject
    private Conversation conversation;
    
    public void incrementar(){
      if (conversation.isTransient())
      {
          conversation.begin();
      }
        ++contador;
    }
    
    public void finalizar(){
      
    }
    
    public Integer getContador(){
        return contador;
    }
}
